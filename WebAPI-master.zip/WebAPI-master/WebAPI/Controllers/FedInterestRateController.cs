using Microsoft.AspNetCore.Mvc;
using WebAPI.Services;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FedInterestRateController : ControllerBase
    {
        private readonly IFedInterestRateService _fedService;

        public FedInterestRateController(IFedInterestRateService fedService)
        {
            _fedService = fedService;
        }

        [HttpGet(Name = "GetFedInterestRate")]
        public async Task<ActionResult<Models.FedInterestRate>> Get()
        {
            var rate = await _fedService.GetCurrentRateAsync();
            return Ok(rate);
        }
    }
}
