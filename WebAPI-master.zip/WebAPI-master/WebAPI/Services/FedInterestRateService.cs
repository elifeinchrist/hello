using Microsoft.Extensions.Options;
using WebAPI.Configuration;

namespace WebAPI.Services
{
    public interface IFedInterestRateService
    {
        Task<Models.FedInterestRate> GetCurrentRateAsync();
    }

    public class FedInterestRateService : IFedInterestRateService
    {
        private readonly HttpClient _httpClient;
        private readonly FedApiSettings _settings;

        public FedInterestRateService(HttpClient httpClient, IOptions<FedApiSettings> options)
        {
            _httpClient = httpClient;
            _settings = options.Value;
        }

        public async Task<Models.FedInterestRate> GetCurrentRateAsync()
        {
            try
            {
                var url = $"{_settings.BaseUrl}api_key={_settings.ApiKey}&limit=1&sort_order=desc&file_type=json";
                var response = await _httpClient.GetAsync(url);
                response.EnsureSuccessStatusCode();

                var json = await response.Content.ReadAsStringAsync();
                var data = System.Text.Json.JsonDocument.Parse(json);
                var observations = data.RootElement.GetProperty("observations");

                if (observations.GetArrayLength() > 0)
                {
                    var latest = observations[0];
                    var rateStr = latest.GetProperty("value").GetString();
                    var dateStr = latest.GetProperty("date").GetString();

                    return new Models.FedInterestRate
                    {
                        Rate = decimal.TryParse(rateStr, out var rate) ? rate : 0m,
                        EffectiveDate = DateTime.TryParse(dateStr, out var date) ? date : DateTime.Now,
                        Description = "Federal Funds Rate (DFEDTARU)"
                    };
                }

                return new Models.FedInterestRate { Description = "No data available" };
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Failed to fetch Fed interest rate", ex);
            }
        }
    }
}
