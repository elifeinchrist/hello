namespace WebAPI.Configuration
{
    public class FedApiSettings
    {
        public string ApiKey { get; set; }
        public string BaseUrl { get; set; }
    }
}
