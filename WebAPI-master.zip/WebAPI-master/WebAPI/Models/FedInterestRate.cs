namespace WebAPI.Models
{
    public class FedInterestRate
    {
        public decimal Rate { get; set; }
        public DateTime EffectiveDate { get; set; }
        public string Description { get; set; }
    }
}
